print('Hello Python Basic1')
print('Hello Python Basic2')
print('Hello Python Basic3')
